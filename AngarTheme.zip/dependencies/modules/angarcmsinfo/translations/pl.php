<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Dodaje bloki cms przed stopką.';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_666f6333e43c215212b916fef3d94af0'] = 'Musisz uzupełnić wszystkie pola.';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Musisz wybrać co najmniej jeden sklep.';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Wystąpił błąd podczas zapisu';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nowy własny blok CMS';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Tekst';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Powrót do listy';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Powiązanie sklepu';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'ID bloku';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Sklep';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Tekst bloku';
$_MODULE['<{angarcmsinfo}prestashop>angarcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Dodaj nowy';

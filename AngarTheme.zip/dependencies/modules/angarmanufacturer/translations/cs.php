<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarmanufacturer}prestashop>at_manufacturer_8b88a2c263402b677d3a664bf4524450'] = 'Doporučené výrobce';

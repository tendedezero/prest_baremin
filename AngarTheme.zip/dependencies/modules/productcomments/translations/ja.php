<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productcomments}prestashop>default_dfbe69c6d9568ecb0e65e7b32ed92a3a'] = '商品が見つかりませんでした';
$_MODULE['<{productcomments}prestashop>productcomments_c888438d14855d7d96a2724ee9c306bd'] = '設定は更新されました';
$_MODULE['<{productcomments}prestashop>productcomments_254f642527b45bc260048e30704edb39'] = '設定';
$_MODULE['<{productcomments}prestashop>productcomments_00d23a76e43b46dae9ec7aa9dcbebb32'] = '有効';
$_MODULE['<{productcomments}prestashop>productcomments_b9f5c797ebbf55adccdd8539a65a0241'] = '無効';
$_MODULE['<{productcomments}prestashop>productcomments_c9cc8cce247e49bae79f15173ce97354'] = '保存';
$_MODULE['<{productcomments}prestashop>productcomments_655d20c1ca69519ca647684edbb2db35'] = '高い';
$_MODULE['<{productcomments}prestashop>productcomments_87f8a6ab85c9ced3702b4ea641ad4bb5'] = '中';
$_MODULE['<{productcomments}prestashop>productcomments_28d0edd045e05cf5af64e35ae0c4c6ef'] = '低';
$_MODULE['<{productcomments}prestashop>productcomments_b718adec73e04ce3ec720dd11a06a308'] = 'IDは';
$_MODULE['<{productcomments}prestashop>productcomments_49ee3087348e8d44e1feda1917443987'] = '名前';
$_MODULE['<{productcomments}prestashop>productcomments_a1fa27779242b4902f7ae3bdd5c6d508'] = 'タイプ';
$_MODULE['<{productcomments}prestashop>productcomments_ec53a8c4f07baed5d8825072c89799be'] = 'ステータス';
$_MODULE['<{productcomments}prestashop>productcomments_a517747c3d12f99244ae598910d979c5'] = '作者';
$_MODULE['<{productcomments}prestashop>productcomments_deb10517653c255364175796ace3553f'] = '商品';
$_MODULE['<{productcomments}prestashop>productcomments_91b442d385b54e1418d81adc34871053'] = '選択された';
$_MODULE['<{productcomments}prestashop>productcomments_b56c3bda503a8dc4be356edb0cc31793'] = 'すべて折りたたむ';
$_MODULE['<{productcomments}prestashop>productcomments_5ffd7a335dd836b3373f5ec570a58bdc'] = 'すべてを展開';
$_MODULE['<{productcomments}prestashop>productcomments_5e9df908eafa83cb51c0a3720e8348c7'] = 'すべてチェック';
$_MODULE['<{productcomments}prestashop>productcomments_9747d23c8cc358c5ef78c51e59cd6817'] = 'すべて解除';
$_MODULE['<{productcomments}prestashop>productcomments_4d3d769b812b6faa6b76e1a8abaece2d'] = '実行';
$_MODULE['<{productcomments}prestashop>productcomments_4b3b9db8c9784468094acde0f8bf7071'] = 'グレード';
$_MODULE['<{productcomments}prestashop>productcomments_b5c82723bd85856358f9a376bc613998'] = '%2$d 人中の %1$d の人がこのレビューが役にたった。';
$_MODULE['<{productcomments}prestashop>productcomments_39630ad6ee79b8653ea89194cdb45bec'] = 'このコメントはあなたにとって役に立ちましたか？';
$_MODULE['<{productcomments}prestashop>productcomments_a6105c0a611b41b08f1209506350279e'] = 'はい';
$_MODULE['<{productcomments}prestashop>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'いいえ';
$_MODULE['<{productcomments}prestashop>productcomments_28b3b1e564a00f572c5d4e21da986d49'] = '不正使用の報告';
$_MODULE['<{productcomments}prestashop>productcomments_70397c4b252a5168c5ec003931cea215'] = '必須項目';
$_MODULE['<{productcomments}prestashop>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = '送信';
$_MODULE['<{productcomments}prestashop>productcomments_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'または';
$_MODULE['<{productcomments}prestashop>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'キャンセル';
$_MODULE['<{productcomments}prestashop>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'コメント';
$_MODULE['<{productcomments}prestashop>products-comparison_b1897515d548a960afe49ecf66a29021'] = '平均';
$_MODULE['<{productcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'コメント';
$_MODULE['<{productcomments}prestashop>productcomments-extra_899139b5174d8d7a6e38a0360008a695'] = 'ユーザレビューを読む';
$_MODULE['<{productcomments}prestashop>productcomments-extra_c31732fda0c6f01c446db7163b214de4'] = 'レビューを書く';
$_MODULE['<{productcomments}prestashop>productcomments_93cba07454f06a4a960172bbd6e2a435'] = 'はい';
$_MODULE['<{productcomments}prestashop>productcomments_bafd7322c6e97d25b6299b5d6fe8920b'] = 'いいえ';
$_MODULE['<{productcomments}prestashop>productcomments_c31732fda0c6f01c446db7163b214de4'] = 'レビューを書く';
$_MODULE['<{productcomments}prestashop>productcomments_a4d3b161ce1309df1c4e25df28694b7b'] = '提出';
$_MODULE['<{productcomments}prestashop>productcomments_34e80a799d144cfe4af46815e103f017'] = 'レビュー';

return $_MODULE;

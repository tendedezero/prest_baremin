<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarcatproduct}prestashop>at_catproduct_03c2e7e41ffc181a4e84080b4710e81e'] = 'Νέο';
$_MODULE['<{angarcatproduct}prestashop>at_catproduct_2d0f6b8300be19cf35e89e66f0677f95'] = 'Αγορά';

<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarcatproduct}prestashop>at_catproduct_03c2e7e41ffc181a4e84080b4710e81e'] = 'Novo';
$_MODULE['<{angarcatproduct}prestashop>at_catproduct_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Oferta!';
$_MODULE['<{angarcatproduct}prestashop>at_catproduct_2d0f6b8300be19cf35e89e66f0677f95'] = 'Engadir ao carro';

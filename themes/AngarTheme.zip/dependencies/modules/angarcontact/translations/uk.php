<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarcontact}prestashop>angarcontact_bbaff12800505b22a853e8b7f4eb6a22'] = 'Контакти';
$_MODULE['<{angarcontact}prestashop>angarcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Телефон:';
$_MODULE['<{angarcontact}prestashop>angarcontact_6a1e265f92087bb6dd18194833fe946b'] = 'Email:';
$_MODULE['<{angarcontact}prestashop>nav_bbaff12800505b22a853e8b7f4eb6a22'] = 'Контакти';
$_MODULE['<{angarcontact}prestashop>nav_673ae02fffb72f0fe68a66f096a01347'] = 'Телефон:';
$_MODULE['<{angarcontact}prestashop>nav_6a1e265f92087bb6dd18194833fe946b'] = 'Email:';

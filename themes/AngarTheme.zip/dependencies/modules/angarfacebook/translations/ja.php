<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{angarfacebook}prestashop>angarfacebook_43d541d80b37ddb75cde3906b1ded452'] = 'Facebook いいねボックスブロック';
$_MODULE['<{angarfacebook}prestashop>angarfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = '設定を更新しました';
$_MODULE['<{angarfacebook}prestashop>angarfacebook_f4f70727dc34561dfde1a3c529b6205c'] = '設定';
$_MODULE['<{angarfacebook}prestashop>angarfacebook_c9cc8cce247e49bae79f15173ce97354'] = '保存';
$_MODULE['<{angarfacebook}prestashop>preview_31fde7b05ac8952dacf4af8a704074ec'] = 'プレビュー';


return $_MODULE;

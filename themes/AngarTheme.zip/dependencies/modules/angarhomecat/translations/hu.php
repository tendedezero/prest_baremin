<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarhomecat}prestashop>at_homecat_ddadcae3e0e8f747111903e9d995bc51'] = 'Kiemelt kategóriák';
$_MODULE['<{angarhomecat}prestashop>at_homecat_891ad007e2e9f2d55be6669cd9abc7a0'] = 'Többet látni';

<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{angarparallax}prestashop>at_parallax_891ad007e2e9f2d55be6669cd9abc7a0'] = 'Se mere';
